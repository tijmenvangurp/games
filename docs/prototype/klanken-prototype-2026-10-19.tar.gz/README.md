# Klankprototype — Nathalie

Deze map is een **snapshot** van het TTS-klankprototype waarmee de definitieve klankset is gekozen. De audio is gegenereerd met Piper `speaches-ai/piper-nl_BE-nathalie-medium` (CC0-dataset) via de lokale Speaches-service.

## Openen

- Pak de map uit en open `index.html` in een browser, of
- start de meegeleverde server vanuit de Spellen-repo:

  ```sh
  corepack pnpm exec tsx scripts/generate-sounds.ts --serve-only --out=<pad-naar-deze-map>
  ```

  en open de URL die het script noemt.

## Inhoud

- `index.html` — beluisterpagina met alle 36 klankeenheden en varianten.
- `sounds.json` — manifest met de varianten en bestanden.
- `nathalie/` — de volledige Nathalie-set: losse letters, fonetische spelling, langzaam, aangehouden, woorden, IPA/SSML en de knipvarianten.
- `LICENSES.md` — herkomst en licentie (CC0 1.0).

## Gekozen set

De definitieve set staat in `apps/games/public/audio/letters/v1/sounds/` met `manifest.json`:

- korte klinkers: fonetisch
- lange klinkers en tweetekenklinkers: losse letter; `oe` = `oeh`, `eu` = `euh`
- medeklinkers: fonetisch
- `f, l, m, s, v, z`: 100 ms uit een woord geknipt
- `ng` en `ch`: hele woorden (`lang`, `lach`)

Deze snapshot blijft bedoeld voor vergelijking en onderzoek; de app gebruikt alleen de gekozen bestanden. De kwaliteitsroute blijft een menselijke opname-set (ADR 0017, route B).
